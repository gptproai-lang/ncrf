# Deploy-NCRApp.ps1
# PowerShell script to deploy NCR App to IIS

$SiteName = "NCRApp"
$AppPath = "C:\inetpub\wwwroot\NCRForm"
$Port = 8080 # Using 8080 to avoid conflict with Default Web Site

Write-Host "Starting Deployment for $SiteName..." -ForegroundColor Cyan

# 1. Check if IIS is installed (Simplified check)
if (!(Get-Service W3SVC -ErrorAction SilentlyContinue)) {
    Write-Host "WARNING: IIS (W3SVC) service not found. Ensure IIS is installed." -ForegroundColor Yellow
}

# 2. Check dependencies (URL Rewrite, iisnode)
$iisnodeFound = $false
if (Test-Path "$env:ProgramFiles\iisnode") { $iisnodeFound = $true }
if (Test-Path "${env:ProgramFiles(x86)}\iisnode") { $iisnodeFound = $true }

if (!$iisnodeFound) {
    Write-Host "WARNING: iisnode not found in default locations. Ensure it is installed." -ForegroundColor Yellow
    Write-Host "Download: https://github.com/azure/iisnode" -ForegroundColor Gray
}

# 3. Create Web Site
Import-Module WebAdministration

if (Test-Path "IIS:\Sites\$SiteName") {
    Write-Host "Site $SiteName already exists. Stopping and starting..." -ForegroundColor Yellow
    Stop-WebSite -Name $SiteName
    Start-WebSite -Name $SiteName
}
else {
    Write-Host "Creating new IIS Site: $SiteName on port $Port..." -ForegroundColor Green
    New-WebSite -Name $SiteName -Port $Port -PhysicalPath $AppPath -ApplicationPool "DefaultAppPool"
}

# 4. Set Permissions
# Grant 'IIS AppPool\DefaultAppPool' full control (for SQLite/File logs/Photos)
$AppPoolName = "DefaultAppPool" 
$FileSystemAccessRule = New-Object System.Security.AccessControl.FileSystemAccessRule("IIS AppPool\$AppPoolName", "FullControl", "ContainerInherit, ObjectInherit", "None", "Allow")

$Acl = Get-Acl $AppPath
$Acl.SetAccessRule($FileSystemAccessRule)
Set-Acl $AppPath $Acl

# Also for C:\NCRPhotos
$PhotoPath = "C:\NCRPhotos"
if (!(Test-Path $PhotoPath)) {
    New-Item -ItemType Directory -Path $PhotoPath | Out-Null
}
$PhotoAcl = Get-Acl $PhotoPath
$PhotoAcl.SetAccessRule($FileSystemAccessRule)
Set-Acl $PhotoPath $PhotoAcl

Write-Host "Permissions updated for $AppPoolName." -ForegroundColor Green

Write-Host "Deployment Complete!" -ForegroundColor Cyan
Write-Host "Access the app at: http://localhost:$Port/NCR_Login.html" -ForegroundColor Cyan
