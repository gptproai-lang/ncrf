// Check if user is logged in and handle RBAC
const employeeId = sessionStorage.getItem('employeeId');
const employeeRole = sessionStorage.getItem('employeeRole');

if (!employeeId) {
    window.location.href = 'NCR_Login.html';
} else if (employeeRole && employeeRole.toLowerCase() === 'production') {
    // Production role not allowed here
    window.location.href = 'NCR_New_Report.html';
}

function signOut() {
    sessionStorage.clear();
    window.location.href = 'NCR_Login.html';
}

// Chart instance variable
let trendsChart = null;

// Initialize dashboard
async function initDashboard() {
    const yearSelect = document.getElementById('filter-year');
    const currentYear = new Date().getFullYear().toString();

    try {
        // Fetch years from database
        const response = await fetch('/api/years');
        const years = await response.json();

        yearSelect.innerHTML = ''; // Clear existing

        if (years.length === 0) {
            // Fallback to current year if no reports exist
            const option = document.createElement('option');
            option.value = currentYear;
            option.textContent = currentYear;
            yearSelect.appendChild(option);
        } else {
            years.forEach(year => {
                const option = document.createElement('option');
                option.value = year;
                option.textContent = year;
                if (year.toString() === currentYear) option.selected = true;
                yearSelect.appendChild(option);
            });
        }
    } catch (error) {
        console.error('Error fetching years:', error);
        // Fallback on error
        yearSelect.innerHTML = `<option value="${currentYear}">${currentYear}</option>`;
    }

    await updateCharts();
}

// Update charts and tables function
async function updateCharts() {
    const selectedYear = document.getElementById('filter-year').value;
    // Month filtering is tricky with current filtered SP, let's just fetch year data 
    // and filter client side if needed, or update SP to accept month.
    // For now, let's just show year data as the SP is designed for Year.
    // If user selects a month, we can filter the arrays in JS.
    const selectedMonth = document.getElementById('filter-month').value;

    try {
        // Use month in the API call if selected
        const url = selectedMonth ? `/api/dashboard?year=${selectedYear}&month=${selectedMonth}` : `/api/dashboard?year=${selectedYear}`;
        const response = await fetch(url);
        const data = await response.json();

        if (data.error) throw new Error(data.error);

        processDashboardData(data, selectedMonth);

    } catch (error) {
        console.error('Error fetching dashboard data:', error);
        // Optionally show error state
    }
}

// 1. Status Overview Cards
function processDashboardData(data, selectedMonth) {
    // Unpack data
    const { statusCounts, severityByMonth, departmentStats, departmentSeverity } = data;

    // 1. Status Overview Cards
    const statusMap = { 'open': 0, 'closed': 0, 'cancelled': 0 };
    statusCounts.forEach(item => {
        if (item.Status) statusMap[item.Status.toLowerCase()] = item.Count;
    });
    document.getElementById('open-count').textContent = statusMap.open;
    document.getElementById('closed-count').textContent = statusMap.closed;
    document.getElementById('cancelled-count').textContent = statusMap.cancelled;

    // 2. Trends Chart
    updateTrendsChart(severityByMonth);

    // 3. Department Tables
    updateDepartmentTables(departmentStats, departmentSeverity);
}

function updateTrendsChart(severityData) {
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const major = new Array(12).fill(0);
    const moderate = new Array(12).fill(0);
    const minor = new Array(12).fill(0);

    severityData.forEach(item => {
        const idx = item.Month - 1;
        const sev = (item.Severity || '').toLowerCase();
        if (sev === 'major') major[idx] = item.Count;
        if (sev === 'moderate') moderate[idx] = item.Count;
        if (sev === 'minor') minor[idx] = item.Count;
    });

    const trendsCtx = document.getElementById('trendsChart').getContext('2d');
    if (trendsChart) trendsChart.destroy();

    trendsChart = new Chart(trendsCtx, {
        type: 'bar',
        data: {
            labels: months,
            datasets: [
                { label: 'Major', data: major, backgroundColor: '#fee2e2', borderColor: '#dc2626', borderWidth: 1 },
                { label: 'Moderate', data: moderate, backgroundColor: '#fed7aa', borderColor: '#ea580c', borderWidth: 1 },
                { label: 'Minor', data: minor, backgroundColor: '#fef3c7', borderColor: '#d97706', borderWidth: 1 }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                x: { stacked: true },
                y: { stacked: true, beginAtZero: true }
            },
            plugins: { legend: { position: 'bottom' } }
        }
    });
}

function updateDepartmentTables(deptStats, deptSeverity) {
    const departments = ['Engineering', 'Maintenance', 'Production', 'Quality'];
    const statusTableBody = document.getElementById('dept-status-body');
    statusTableBody.innerHTML = '';
    const severityTableBody = document.getElementById('dept-severity-body');
    severityTableBody.innerHTML = '';

    const deptStatusData = {};
    departments.forEach(d => deptStatusData[d] = { Open: 0, Closed: 0, Cancelled: 0 });

    deptStats.forEach(item => {
        const dept = departments.find(d => d.toLowerCase() === (item.Department || '').toLowerCase());
        if (dept) {
            const status = Object.keys(deptStatusData[dept]).find(s => s.toLowerCase() === (item.Status || '').toLowerCase());
            if (status) deptStatusData[dept][status] = item.Count;
        }
    });

    const deptSeverityData = {};
    departments.forEach(d => deptSeverityData[d] = { Major: 0, Moderate: 0, Minor: 0 });

    if (deptSeverity) {
        deptSeverity.forEach(item => {
            const dept = departments.find(d => d.toLowerCase() === (item.Department || '').toLowerCase());
            if (dept) {
                const sev = Object.keys(deptSeverityData[dept]).find(s => s.toLowerCase() === (item.Severity || '').toLowerCase());
                if (sev) deptSeverityData[dept][sev] = item.Count;
            }
        });
    }

    departments.forEach(dept => {
        // Status Row
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${dept}</td>
            <td>${deptStatusData[dept].Open}</td>
            <td>${deptStatusData[dept].Closed}</td>
            <td>${deptStatusData[dept].Cancelled}</td>
        `;
        statusTableBody.appendChild(row);

        // Severity Row
        const rowSev = document.createElement('tr');
        rowSev.innerHTML = `
            <td>${dept}</td>
            <td>${deptSeverityData[dept].Major}</td>
            <td>${deptSeverityData[dept].Moderate}</td>
            <td>${deptSeverityData[dept].Minor}</td>
        `;
        severityTableBody.appendChild(rowSev);
    });
}

// Initial Load
initDashboard();
