// Check if user is logged in and handle RBAC
const employeeId = sessionStorage.getItem('employeeId');
const employeeRole = sessionStorage.getItem('employeeRole');

if (!employeeId) {
    window.location.href = 'NCR_Login.html';
} else {
    console.log('Logged in as:', employeeId, 'Role:', employeeRole);

    // If production, hide other tabs except Sign Out
    if (employeeRole && employeeRole.toLowerCase() === 'production') {
        document.querySelectorAll('.nav-tab').forEach(tab => {
            if (!tab.classList.contains('active') && !tab.classList.contains('sign-out')) {
                tab.style.display = 'none';
            }
        });
    }
}

function signOut() {
    sessionStorage.clear();
    window.location.href = 'NCR_Login.html';
}

// Get all form inputs
const formInputs = [
    document.getElementById('tank-serial'),
    document.getElementById('department'),
    document.getElementById('auditee'),
    document.getElementById('auditor'),
    document.getElementById('lead-hand'),
    document.getElementById('manager'),
    document.getElementById('severity'),
    document.getElementById('non-conformance')
];

const submitButton = document.querySelector('.submit-button');
let autoRedirectTimeout;

// Function to check if all fields are filled
function checkFormCompletion() {
    const allFilled = formInputs.every(input => input.value.trim() !== '');

    if (allFilled) {
        submitButton.classList.add('active');
    } else {
        submitButton.classList.remove('active');
    }
}

// Add event listeners to all inputs
formInputs.forEach(input => {
    input.addEventListener('input', checkFormCompletion);
    input.addEventListener('change', checkFormCompletion);
});

// Limit tank serial to 5 characters
document.getElementById('tank-serial').addEventListener('input', function (e) {
    if (e.target.value.length > 5) {
        e.target.value = e.target.value.slice(0, 5);
    }
});


// Format date and time
function formatDateTime(date) {
    const year = date.getFullYear();
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const day = String(date.getDate()).padStart(2, '0');

    let hours = date.getHours();
    const minutes = String(date.getMinutes()).padStart(2, '0');
    const seconds = String(date.getSeconds()).padStart(2, '0');
    const ampm = hours >= 12 ? 'PM' : 'AM';

    hours = hours % 12;
    hours = hours ? hours : 12; // the hour '0' should be '12'
    const formattedHours = String(hours).padStart(2, '0');

    return `${year}-${month}-${day} ${formattedHours}:${minutes}:${seconds} ${ampm}`;
}

// Start auto-redirect timer
function startAutoRedirect() {
    autoRedirectTimeout = setTimeout(() => {
        window.location.href = 'NCR_Login.html';
    }, 5000); // 5 seconds
}

// Stop auto-redirect timer
function stopAutoRedirect() {
    if (autoRedirectTimeout) {
        clearTimeout(autoRedirectTimeout);
    }
}

// Show success modal
function showSuccessModal(ncrNumber, timestamp) {
    const modal = document.getElementById('successModal');
    document.getElementById('ncrNumber').textContent = ncrNumber;
    document.getElementById('lastModified').textContent = timestamp;
    modal.classList.add('show');

    // Start auto-redirect countdown
    startAutoRedirect();
}

// Submit another report
function submitAnotherReport() {
    stopAutoRedirect();
    const modal = document.getElementById('successModal');
    modal.classList.remove('show');

    // Clear all form fields
    formInputs.forEach(input => {
        input.value = '';
    });

    // Clear photos
    uploadedFiles = [];
    document.getElementById('file-list').innerHTML = '';

    // Reset button state
    checkFormCompletion();

    // Scroll to top
    window.scrollTo(0, 0);
}

// Stop auto-redirect when user interacts with modal
document.getElementById('successModal').addEventListener('click', function (e) {
    if (e.target.classList.contains('modal-button')) {
        return; // Let the button handler take over
    }
    stopAutoRedirect();
    startAutoRedirect(); // Restart the timer
});

// Tab navigation
document.querySelectorAll('.nav-tab').forEach(tab => {
    tab.addEventListener('click', function () {
        document.querySelectorAll('.nav-tab').forEach(t => t.classList.remove('active'));
        this.classList.add('active');
    });
});

// Form submission
submitButton.addEventListener('click', async function () {
    // Check if form is complete
    const allFilled = formInputs.every(input => input.value.trim() !== '');

    if (!allFilled) {
        alert('Please fill in all required fields.');
        return;
    }

    // Generate timestamp
    const timestamp = formatDateTime(new Date());

    // Convert photos to base64
    const photoData = await Promise.all(uploadedFiles.map((file, index) => {
        return new Promise((resolve) => {
            const reader = new FileReader();
            reader.onload = (e) => resolve({ data: e.target.result });
            reader.readAsDataURL(file);
        });
    }));

    // Collect form data
    const formData = {
        employeeId: employeeId,
        tankSerial: document.getElementById('tank-serial').value,
        department: document.getElementById('department').value,
        auditee: document.getElementById('auditee').value,
        auditor: document.getElementById('auditor').value,
        leadHand: document.getElementById('lead-hand').value,
        manager: document.getElementById('manager').value,
        severity: document.getElementById('severity').value,
        status: 'open',
        nonConformance: document.getElementById('non-conformance').value,
        created: timestamp,
        lastModified: timestamp
    };

    // Send to Backend API
    fetch('/api/reports', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
            report: formData,
            photos: photoData
        })
    })
        .then(response => response.json())
        .then(result => {
            if (result.success) {
                console.log('Report submitted successfully');
                showSuccessModal(result.ncrNo, timestamp);
            } else {
                throw new Error(result.error || 'Submission failed');
            }
        })
        .catch(error => {
            console.error('Error submitting report:', error);
            alert('Failed to submit report. Please try again.\nError: ' + error.message);
        });
});

// Initial check
checkFormCompletion();

// Camera and File Upload Logic
const cameraInput = document.getElementById('camera-input');
const cameraButtonLabel = document.querySelector('.camera-button');
const fileInput = document.getElementById('file-input');
const dropZone = document.getElementById('drop-zone');
const fileList = document.getElementById('file-list');

let uploadedFiles = [];

// Explicit camera trigger for better mobile compatibility
if (cameraButtonLabel) {
    cameraButtonLabel.addEventListener('click', (e) => {
        e.preventDefault();
        // The label default for="camera-input" usually works, 
        // but explicit click ensures bypass of some mobile browser quirks.
        cameraInput.click();
    });
}

// Function to handle file selection
function handleFiles(files) {
    const filesArray = Array.from(files);

    filesArray.forEach(file => {
        if (file.type.startsWith('image/')) {
            uploadedFiles.push(file);

            const reader = new FileReader();
            reader.onload = (e) => {
                const fileItem = document.createElement('div');
                fileItem.className = 'file-item';
                fileItem.innerHTML = `
                    <img src="${e.target.result}" alt="Preview">
                    <button class="remove-btn" onclick="removeFile(this, '${file.name}')">&times;</button>
                `;
                fileList.appendChild(fileItem);
            };
            reader.readAsDataURL(file);
        }
    });
}

// Remove file function
window.removeFile = (btn, fileName) => {
    uploadedFiles = uploadedFiles.filter(f => f.name !== fileName);
    btn.parentElement.remove();
};

// Camera Input Trigger
cameraInput.addEventListener('change', (e) => {
    handleFiles(e.target.files);
});

// Click to browse
dropZone.addEventListener('click', () => {
    fileInput.click();
});

fileInput.addEventListener('change', (e) => {
    handleFiles(e.target.files);
});

// Drag and Drop implementation
dropZone.addEventListener('dragover', (e) => {
    e.preventDefault();
    dropZone.classList.add('drag-over');
});

['dragleave', 'dragend'].forEach(type => {
    dropZone.addEventListener(type, () => {
        dropZone.classList.remove('drag-over');
    });
});

dropZone.addEventListener('drop', (e) => {
    e.preventDefault();
    dropZone.classList.remove('drag-over');
    handleFiles(e.dataTransfer.files);
});
