// Check if user is logged in and handle RBAC
const employeeId = sessionStorage.getItem('employeeId');
const employeeRole = sessionStorage.getItem('employeeRole');

if (!employeeId) {
    window.location.href = 'NCR_Login.html';
} else if (employeeRole && employeeRole.toLowerCase() === 'production') {
    // Production role not allowed here
    window.location.href = 'NCR_New_Report.html';
}

function signOut() {
    sessionStorage.clear();
    window.location.href = 'NCR_Login.html';
}

let currentPage = 1;
const limit = 10;

async function loadReports(page = 1) {
    currentPage = page;
    const department = document.getElementById('departmentFilter').value;  // Update ID if different
    const status = document.getElementById('filter-status').value;
    const severity = document.getElementById('filter-severity').value;

    const response = await fetch(`/api/reports?department=${department}&status=${status}&severity=${severity}&page=${page}&limit=${limit}`);
    const data = await response.json();

    const tableBody = document.getElementById('reportsTable').getElementsByTagName('tbody')[0];
    tableBody.innerHTML = '';

    data.reports.forEach(report => {
        const row = tableBody.insertRow();
        row.insertCell(0).textContent = report.NCRNumber;
        row.insertCell(1).textContent = report.TankSerial;
        row.insertCell(2).textContent = report.Department;
        row.insertCell(3).textContent = report.Status;
        row.insertCell(4).textContent = report.Severity;
        row.insertCell(5).textContent = new Date(report.CreatedDate).toLocaleDateString();
        row.insertCell(6).textContent = report.ClosedDate ? new Date(report.ClosedDate).toLocaleDateString() : '';
        // Add edit button if needed
        const editCell = row.insertCell(7);
        const editBtn = document.createElement('button');
        editBtn.textContent = 'Edit';
        editBtn.onclick = () => editReport(report.NCRNumber);
        editCell.appendChild(editBtn);
    });

    updatePagination(data.totalPages, data.page);
}

function updatePagination(totalPages, currentPage) {
    const paginationDiv = document.getElementById('pagination');
    paginationDiv.innerHTML = '';

    if (totalPages > 1) {
        const prevBtn = document.createElement('button');
        prevBtn.textContent = 'Prev';
        prevBtn.disabled = currentPage === 1;
        prevBtn.onclick = () => loadReports(currentPage - 1);
        paginationDiv.appendChild(prevBtn);

        for (let i = 1; i <= totalPages; i++) {
            const pageBtn = document.createElement('button');
            pageBtn.textContent = i;
            pageBtn.className = i === currentPage ? 'active' : '';
            pageBtn.onclick = () => loadReports(i);
            paginationDiv.appendChild(pageBtn);
        }

        const nextBtn = document.createElement('button');
        nextBtn.textContent = 'Next';
        nextBtn.disabled = currentPage === totalPages;
        nextBtn.onclick = () => loadReports(currentPage + 1);
        paginationDiv.appendChild(nextBtn);
    }
}

// Edit report function (kept from existing)
function editReport(ncrNo) {
    sessionStorage.setItem('editingNCR', ncrNo);
    window.location.href = 'NCR_Editing_Report.html?ncr=' + ncrNo;
}

// Update filter event listeners to reset to page 1
document.getElementById('filter-date').addEventListener('change', () => loadReports(1));  // If date filter exists
document.getElementById('filter-status').addEventListener('change', () => loadReports(1));
document.getElementById('filter-severity').addEventListener('change', () => loadReports(1));

// Initial load
loadReports();