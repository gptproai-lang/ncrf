USE NCR_DB;
GO

-- Table: Users
-- Stores employee login details and roles
IF NOT EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[Users]') AND type in (N'U'))
BEGIN
    CREATE TABLE [dbo].[Users](
        [EmployeeID] [nvarchar](50) NOT NULL,
        [FullName] [nvarchar](100) NULL,
        [Role] [nvarchar](50) NOT NULL,
        [IsActive] [bit] NOT NULL DEFAULT 1,
        [CreatedAt] [datetime] DEFAULT GETDATE(),
        CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED ([EmployeeID] ASC)
    );
END
GO

-- Cleanup for Fresh Start (Resetting IDs to NCR00000)
IF OBJECT_ID('dbo.NCR_Photos', 'U') IS NOT NULL 
    DROP TABLE dbo.NCR_Photos;

IF OBJECT_ID('dbo.NCR_Reports', 'U') IS NOT NULL 
    DROP TABLE dbo.NCR_Reports;
GO

-- Table: NCR_Reports
CREATE TABLE [dbo].[NCR_Reports](
    [Id] [int] IDENTITY(0,1) NOT NULL,
    [NCRNumber] AS (CAST('NCR' + RIGHT('00000' + CAST([Id] AS [nvarchar](10)), 5) AS NVARCHAR(20))) PERSISTED NOT NULL,
    [TankSerial] [nvarchar](20) NOT NULL,
    [Department] [nvarchar](50) NOT NULL,
    [Auditee] [nvarchar](100) NOT NULL,
    [Auditor] [nvarchar](100) NOT NULL,
    [LeadHand] [nvarchar](100) NOT NULL,
    [Manager] [nvarchar](100) NOT NULL,
    [Severity] [nvarchar](20) NOT NULL,
    [Status] [nvarchar](20) NOT NULL DEFAULT 'Open',
    [NonConformanceDescription] [nvarchar](max) NOT NULL,
    [CorrectiveAction] [nvarchar](max) NULL,
    [RootCause] [nvarchar](max) NULL,
    [CreatedBy] [nvarchar](50) NOT NULL,
    [CreatedDate] [datetime] NOT NULL DEFAULT GETDATE(),
    [LastModifiedDate] [datetime] NOT NULL DEFAULT GETDATE(),
    [ClosedDate] [datetime] NULL,
    CONSTRAINT [PK_NCR_Reports] PRIMARY KEY CLUSTERED ([NCRNumber] ASC),
    CONSTRAINT [FK_NCR_Reports_Users] FOREIGN KEY ([CreatedBy]) REFERENCES [dbo].[Users] ([EmployeeID])
);
GO

-- Table: NCR_Photos
CREATE TABLE [dbo].[NCR_Photos](
    [PhotoID] [int] IDENTITY(1,1) NOT NULL,
    [NCRNumber] [nvarchar](20) NOT NULL,
    [FileName] [nvarchar](255) NOT NULL,
    [PhotoPath] [nvarchar](500) NOT NULL,
    [UploadedDate] [datetime] DEFAULT GETDATE(),
    CONSTRAINT [PK_NCR_Photos] PRIMARY KEY CLUSTERED ([PhotoID] ASC),
    CONSTRAINT [FK_NCR_Photos_NCR_Reports] FOREIGN KEY ([NCRNumber]) REFERENCES [dbo].[NCR_Reports] ([NCRNumber]) ON DELETE CASCADE
);
GO

-- =============================================
-- 2. Indexes
-- =============================================

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_NCR_Reports_Status' AND object_id = OBJECT_ID('dbo.NCR_Reports'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_NCR_Reports_Status] ON [dbo].[NCR_Reports] ([Status]);
END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_NCR_Reports_Severity' AND object_id = OBJECT_ID('dbo.NCR_Reports'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_NCR_Reports_Severity] ON [dbo].[NCR_Reports] ([Severity]);
END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_NCR_Reports_CreatedDate' AND object_id = OBJECT_ID('dbo.NCR_Reports'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_NCR_Reports_CreatedDate] ON [dbo].[NCR_Reports] ([CreatedDate]);
END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Users_Role' AND object_id = OBJECT_ID('dbo.Users'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_Users_Role] ON [dbo].[Users] ([Role]);
END
GO

-- =============================================
-- 3. Stored Procedures
-- =============================================

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_GetDashboardStats]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[sp_GetDashboardStats];
GO

CREATE PROCEDURE [dbo].[sp_GetDashboardStats]
    @Year INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT Status, COUNT(*) as Count FROM NCR_Reports WHERE YEAR(CreatedDate) = @Year GROUP BY Status;
    SELECT MONTH(CreatedDate) as Month, Severity, COUNT(*) as Count FROM NCR_Reports WHERE YEAR(CreatedDate) = @Year GROUP BY MONTH(CreatedDate), Severity ORDER BY Month;
    SELECT Department, Status, COUNT(*) as Count FROM NCR_Reports WHERE YEAR(CreatedDate) = @Year GROUP BY Department, Status;
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_CreateNCR]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[sp_CreateNCR];
GO

CREATE PROCEDURE [dbo].[sp_CreateNCR]
    @TankSerial NVARCHAR(20),
    @Department NVARCHAR(50),
    @Auditee NVARCHAR(100),
    @Auditor NVARCHAR(100),
    @LeadHand NVARCHAR(100),
    @Manager NVARCHAR(100),
    @Severity NVARCHAR(20),
    @NonConformance NVARCHAR(MAX),
    @CreatedBy NVARCHAR(50)
AS
BEGIN
    INSERT INTO NCR_Reports (TankSerial, Department, Auditee, Auditor, LeadHand, Manager, Severity, NonConformanceDescription, CreatedBy)
    VALUES (@TankSerial, @Department, @Auditee, @Auditor, @LeadHand, @Manager, @Severity, @NonConformance, @CreatedBy);
    SELECT TOP 1 NCRNumber FROM NCR_Reports WHERE Id = SCOPE_IDENTITY();
END
GO

IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_UpdateNCR]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[sp_UpdateNCR];
GO

CREATE PROCEDURE [dbo].[sp_UpdateNCR]
    @NCRNumber NVARCHAR(20),
    @Status NVARCHAR(20),
    @CorrectiveAction NVARCHAR(MAX),
    @RootCause NVARCHAR(MAX)
AS
BEGIN
    UPDATE NCR_Reports
    SET Status = @Status, CorrectiveAction = @CorrectiveAction, RootCause = @RootCause, LastModifiedDate = GETDATE(),
        ClosedDate = CASE WHEN @Status IN ('Closed', 'Cancelled') AND ClosedDate IS NULL THEN GETDATE() WHEN @Status NOT IN ('Closed', 'Cancelled') THEN NULL ELSE ClosedDate END
    WHERE NCRNumber = @NCRNumber;
END
GO

-- =============================================
-- 4. Initial Seed Data
-- =============================================
IF NOT EXISTS (SELECT 1 FROM Users)
BEGIN
    INSERT INTO Users (EmployeeID, Role) VALUES ('1234', 'Production'), ('5678', 'Quality'), ('9999', 'Admin'), ('0001', 'Maintenance'), ('1111', 'Engineering');
END
GO
