USE NCR_DB;

-- =============================================
-- 1. Tables
-- =============================================

-- Table: Users
-- Stores employee login details and roles
CREATE TABLE [dbo].[Users] (
    [EmployeeID]  NVARCHAR(50)  NOT NULL,
    [FullName]    NVARCHAR(100) NULL,
    [Role]        NVARCHAR(50)  NOT NULL,
    [IsActive]    BIT           NOT NULL DEFAULT ((1)),
    [CreatedAt]   DATETIME      NULL     DEFAULT (GETDATE()),
    CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED ([EmployeeID] ASC)
);

-- Table: NCR_Reports
CREATE TABLE [dbo].[NCR_Reports] (
    [Id]                        INT            NOT NULL IDENTITY(0, 1),
    [NCRNumber]                 AS (CONVERT(NVARCHAR(20), 'NCR' + RIGHT('00000' + CONVERT(NVARCHAR(10), [Id]), 5))) PERSISTED NOT NULL,
    [TankSerial]                NVARCHAR(20)   NOT NULL,
    [Department]                NVARCHAR(50)   NOT NULL,
    [Auditee]                   NVARCHAR(100)  NOT NULL,
    [Auditor]                   NVARCHAR(100)  NOT NULL,
    [LeadHand]                  NVARCHAR(100)  NOT NULL,
    [Manager]                   NVARCHAR(100)  NOT NULL,
    [Severity]                  NVARCHAR(20)   NOT NULL,
    [Status]                    NVARCHAR(20)   NOT NULL DEFAULT ('Open'),
    [NonConformanceDescription] NVARCHAR(MAX)  NOT NULL,
    [CorrectiveAction]          NVARCHAR(MAX)  NULL,
    [RootCause]                 NVARCHAR(MAX)  NULL,
    [CreatedBy]                 NVARCHAR(50)   NOT NULL,
    [CreatedDate]               DATETIME       NOT NULL DEFAULT (GETDATE()),
    [LastModifiedDate]          DATETIME       NOT NULL DEFAULT (GETDATE()),
    [ClosedDate]                DATETIME       NULL,
    CONSTRAINT [PK_NCR_Reports] PRIMARY KEY CLUSTERED ([NCRNumber]),
    CONSTRAINT [FK_NCR_Reports_Users] FOREIGN KEY ([CreatedBy]) REFERENCES [dbo].[Users] ([EmployeeID])
);

-- Table: NCR_Photos
CREATE TABLE [dbo].[NCR_Photos] (
    [PhotoID]      INT            NOT NULL IDENTITY(1, 1),
    [NCRNumber]    NVARCHAR(20)   NOT NULL,
    [FileName]     NVARCHAR(255)  NOT NULL,
    [PhotoPath]    NVARCHAR(500)  NOT NULL,
    [UploadedDate] DATETIME       NULL DEFAULT (GETDATE()),
    CONSTRAINT [PK_NCR_Photos] PRIMARY KEY CLUSTERED ([PhotoID]),
    CONSTRAINT [FK_NCR_Photos_NCR_Reports] FOREIGN KEY ([NCRNumber]) REFERENCES [dbo].[NCR_Reports] ([NCRNumber]) ON DELETE CASCADE
);

-- =============================================
-- 2. Indexes
-- =============================================

-- Table: Users
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_Users_Role' AND object_id = OBJECT_ID('dbo.Users'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_Users_Role] ON [dbo].[Users] ([Role]);
END
GO

-- Table: NCR_Reports
IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_NCR_Reports_Status' AND object_id = OBJECT_ID('dbo.NCR_Reports'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_NCR_Reports_Status] ON [dbo].[NCR_Reports] ([Status]);
END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_NCR_Reports_Severity' AND object_id = OBJECT_ID('dbo.NCR_Reports'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_NCR_Reports_Severity] ON [dbo].[NCR_Reports] ([Severity]);
END
GO

IF NOT EXISTS (SELECT * FROM sys.indexes WHERE name = 'IX_NCR_Reports_CreatedDate' AND object_id = OBJECT_ID('dbo.NCR_Reports'))
BEGIN
    CREATE NONCLUSTERED INDEX [IX_NCR_Reports_CreatedDate] ON [dbo].[NCR_Reports] ([CreatedDate]);
END
GO

-- =============================================
-- 3. Stored Procedures
-- =============================================

-- sp_GetDashboardStats
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_GetDashboardStats]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[sp_GetDashboardStats];
GO

CREATE PROCEDURE [dbo].[sp_GetDashboardStats]
    @Year INT,
    @Month INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    -- 1. Status Overall (respects Month)
    SELECT Status, COUNT(*) as Count
    FROM NCR_Reports
    WHERE YEAR(CreatedDate) = @Year
      AND (@Month IS NULL OR MONTH(CreatedDate) = @Month)
    GROUP BY Status;

    -- 2. Monthly Trends (Always full year)
    SELECT MONTH(CreatedDate) as Month, Severity, COUNT(*) as Count
    FROM NCR_Reports
    WHERE YEAR(CreatedDate) = @Year
    GROUP BY MONTH(CreatedDate), Severity
    ORDER BY Month;

    -- 3. Dept Status (respects Month)
    SELECT Department, Status, COUNT(*) as Count
    FROM NCR_Reports
    WHERE YEAR(CreatedDate) = @Year
      AND (@Month IS NULL OR MONTH(CreatedDate) = @Month)
    GROUP BY Department, Status;

    -- 4. Dept Severity (respects Month)
    SELECT Department, Severity, COUNT(*) as Count
    FROM NCR_Reports
    WHERE YEAR(CreatedDate) = @Year
      AND (@Month IS NULL OR MONTH(CreatedDate) = @Month)
    GROUP BY Department, Severity;
END
GO

-- sp_CreateNCR
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_CreateNCR]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[sp_CreateNCR];
GO

CREATE PROCEDURE [dbo].[sp_CreateNCR]
    @NCRNumber NVARCHAR(20),
    @TankSerial NVARCHAR(20),
    @Department NVARCHAR(50),
    @Auditee NVARCHAR(100),
    @Auditor NVARCHAR(100),
    @LeadHand NVARCHAR(100),
    @Manager NVARCHAR(100),
    @Severity NVARCHAR(20),
    @NonConformance NVARCHAR(MAX),
    @CreatedBy NVARCHAR(50)
AS
BEGIN
    INSERT INTO NCR_Reports (
        NCRNumber, TankSerial, Department, Auditee, Auditor, LeadHand, Manager, Severity, NonConformanceDescription, CreatedBy
    )
    VALUES (
        @NCRNumber, @TankSerial, @Department, @Auditee, @Auditor, @LeadHand, @Manager, @Severity, @NonConformance, @CreatedBy
    );
END
GO

-- sp_UpdateNCR
IF EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[dbo].[sp_UpdateNCR]') AND type in (N'P', N'PC'))
    DROP PROCEDURE [dbo].[sp_UpdateNCR];
GO

CREATE PROCEDURE [dbo].[sp_UpdateNCR]
    @NCRNumber NVARCHAR(20),
    @Status NVARCHAR(20),
    @CorrectiveAction NVARCHAR(MAX),
    @RootCause NVARCHAR(MAX)
AS
BEGIN
    UPDATE NCR_Reports
    SET
        Status = @Status,
        CorrectiveAction = @CorrectiveAction,
        RootCause = @RootCause,
        LastModifiedDate = GETDATE(),
        ClosedDate = CASE
            WHEN @Status IN ('Closed', 'Cancelled') AND ClosedDate IS NULL THEN GETDATE()
            WHEN @Status NOT IN ('Closed', 'Cancelled') THEN NULL
            ELSE ClosedDate
        END
    WHERE NCRNumber = @NCRNumber;
END
GO