# NCR Project Documentation ("The Brain")

This file serves as the central knowledge base for the Non-Conformance Report (NCR) system. It documents naming conventions, navigation logic, access controls, and specific functional requirements to ensure consistency and prevent regression.

## 📁 File Structure & Naming Conventions
All core project files follow the `NCR_[Page_Name].html` format:
- `NCR_Login.html`: The initial entry point for employee authentication.
- `NCR_Dashboard.html`: Metrics and trends overview (Restricted).
- `NCR_View_Reports.html`: Search and filter table of submitted reports (Restricted).
- `NCR_New_Report.html`: Form to submit a new NCR (Accessible by all).
- `NCR_Editing_Report.html`: Form to update existing reports (Restricted).

---

## 🔐 Role-Based Access Control (RBAC)
The system uses `sessionStorage` (`employeeId` and `employeeRole`) to manage access. Roles are validated during login against the **Users** table in MS SQL.

### Roles & Redirection
- **Production Role** (e.g., ID `1234`):
    - Redirection: Always directed to `NCR_New_Report.html`.
    - UI Restrictions: Navigation tabs for "View Reports" and "Dashboard" are hidden.
    - Security: **Case-insensitive** checks ensure that roles like `'Production'` or `'production'` are handled correctly. Restricted pages bounce these users back to the New Report page.
- **Administrative Roles** (e.g., Quality, Engineering, Admin):
    - Redirection: Defaulted to `NCR_Dashboard.html` or `NCR_View_Reports.html` upon login.
    - Permissions: Full access to all pages and navigation tabs.

---

## 🛠️ Key Logic & Features

### 1. Navigation Logic
- **Clickable Dashboard**: Clicking the "NCR" or "Dashboard" title in the header redirects to `NCR_Dashboard.html`.
- **Active Tabs**: The `active` class is applied to the current page's tab for visual feedback.

### 2. Report Editing Restrictions (`NCR_Editing_Report.html`)
- **Final State Lock**: If an NCR's status is changed to **Closed** or **Cancelled** and saved:
    - The `Corrective Action` and `Root Cause / Remarks` textareas are automatically disabled.
    - The `NCR Status` dropdown is disabled to prevent further changes after finalization.
- **Initial Load Check**: The `populateForm()` function checks the status on load; if already closed/cancelled, fields are pre-disabled.

### 3. Authentication Persistence
- Every page contains a script block to check for `employeeId` in `sessionStorage`.
- If missing, the user is redirected to `NCR_Login.html`.

### 4. Camera & File Upload Logic
- **Generic Camera Access**: Uses `<input type="file" accept="image/*" capture="environment">`. This is a universal standard that tells mobile browsers to open the native camera app immediately upon button click, eliminating the need for device-specific scripts.
- **Drag & Drop**: Implemented using `dragover`, `dragleave`, and `drop` event listeners. It provides visual feedback (border color change) when a file is dragged over the zone.
- **Image Previews**:
    - **New Report**: Dynamically creates `<img>` tags in a preview grid after file selection. Photos are cleared upon successful submission or form reset.
    - **Editing Report**: Displays a dedicated "Evidence & Photos" card if photos exist. Includes a **Lightbox Modal** for full-size viewing when a photo is clicked.
- **Remove Feature**: Each uploaded image in the New Report form has a "remove" button to manage selections.

---

### 5. Data Persistence (MS SQL Server)
- **Storage Strategy**: Data is persisted in an MS SQL Server database (`NCR_DB`).
- **Server**: A Node.js server (`server.js`) using `express` and `mssql` provides the API.
- **Photo Storage**: Photos are saved to the file system at `C:\NCRPhotos`. The file paths and metadata are stored in the `NCR_Photos` table.
- **Dashboard Synchronization**: The `NCR_Dashboard.html` page fetches aggregated data via the `/api/dashboard` endpoint, which executes the `sp_GetDashboardStats` stored procedure for high-performance reporting.
- **Real-Time Updates**: Upon saving a report in `NCR_New_Report.html` or `NCR_Editing_Report.html`, the client performs a `POST` or `PUT` request to the API, ensuring immediate consistency across the system.

### 6. Date & Time Management
- **Standard Utility**: The `formatDateTime(date)` function ensures consistent timestamp formatting.
- **Tracking**:
    - `CreatedDate`: Set automatically upon initial submission.
    - `LastModifiedDate`: Updated on every edit.
    - `ClosedDate`: Automatically set when an NCR status transitions to **Closed** or **Cancelled**. If reverted to **Open**, this field is cleared.

---

### 6. Sign Out Functionality
- **Logic**: All restricted pages include a **Sign Out Icon**. Clicking it immediately runs `sessionStorage.clear()` and redirects the user to `NCR_Login.html`.
- **Visibility**: The icon is positioned at the far right of the navigation bar using `margin-left: auto`. It includes a red hover effect and a "Sign Out" tooltip for accessibility.

### 7. Photo Handling & Naming
- **Naming Convention**: Photos are automatically renamed during submission to match `${NCRNumber}_${Index}` (e.g., `NCR20888_1`). This ensures clear identification even if the original file had a generic name.
- **Storage**: Reports and photos are stored in **MS SQL Server**.
- **Display**: Photos are displayed in a grid in `NCR_Editing_Report.html`, and clicking them opens a full-screen Lightbox.

---

## ⚠️ Common Pitfalls & Lessons Learned
- **Path Consistency**: Always ensure links between pages use the full standardized filename (e.g., `NCR_Dashboard.html`, not relative paths or short names).
- **Session Handling**: Remember that `sessionStorage` is cleared when the tab is closed.
- **Tab Hiding**: When hiding tabs for the production role, the script uses `querySelectorAll('.nav-tab')` and filters based on text content or class to avoid hiding the "New Report" tab.
- **Camera Capture**: Note that `capture="environment"` strictly targets the back camera on mobile. For general uploads (including existing gallery photos), use a separate file picker without the `capture` attribute.
- **SQL Syntax Sensitivity**: T-SQL is sensitive to stray characters. When copying SQL code from a code viewer or AI assistant, ensure that formatting markers like `<line_number>` or stray brackets (`<`, `>`) are not accidentally included in the execution script, as they will cause syntax errors.

---
*Last Updated: 2026-02-08*
