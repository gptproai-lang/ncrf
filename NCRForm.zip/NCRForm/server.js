const express = require('express');
const sql = require('mssql');
const cors = require('cors');
const bodyParser = require('body-parser');
const path = require('path');
const fs = require('fs');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.urlencoded({ limit: '50mb', extended: true }));

// Serve static files (HTML, CSS, JS) from the root directory
app.use(express.static(__dirname));

// Serve uploaded photos
const PHOTOS_DIR = 'C:\\NCRPhotos';
if (!fs.existsSync(PHOTOS_DIR)) {
    fs.mkdirSync(PHOTOS_DIR, { recursive: true });
}
app.use('/photos', express.static(PHOTOS_DIR));

// Database Configuration
const dbConfig = {
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    server: process.env.DB_SERVER,
    database: process.env.DB_NAME,
    options: {
        encrypt: false, // For local dev. Set to true if using Azure
        trustServerCertificate: true
    }
};

// Connect to Database
sql.connect(dbConfig).then(pool => {
    if (pool.connected) {
        console.log('Connected to MS SQL Server');
    }
}).catch(err => {
    console.error('Database connection failed:', err);
});

// Helper for consistency
function sendError(res, err, message = 'Internal Server Error') {
    console.error(message, err);
    res.status(500).json({ error: message, details: err.message });
}

// ================= API Endpoints =================

// 1. Login
app.post('/api/login', async (req, res) => {
    try {
        const { employeeId } = req.body;
        if (!employeeId) return res.status(400).json({ error: 'Employee ID required' });

        const pool = await sql.connect(dbConfig);
        const result = await pool.request()
            .input('Id', sql.NVarChar, employeeId)
            .query('SELECT EmployeeID, Role FROM Users WHERE EmployeeID = @Id');

        if (result.recordset.length > 0) {
            const user = result.recordset[0];
            // In a real app, use JWT here. For now, specific cookie/session logic can be added later as per plan.
            // Sending back role for frontend redirection
            res.json({ success: true, role: user.Role, employeeId: user.EmployeeID });
        } else {
            res.status(401).json({ error: 'Invalid Credentials' });
        }
    } catch (err) {
        sendError(res, err, 'Login failed');
    }
});

// 2. Get All Reports (with filters)
app.get('/api/reports', async (req, res) => {
    try {
        const pool = await sql.connect(dbConfig);
        const result = await pool.request().query(`
            SELECT * FROM NCR_Reports 
            ORDER BY CreatedDate DESC
        `);
        res.json(result.recordset);
    } catch (err) {
        sendError(res, err, 'Failed to fetch reports');
    }
});

// 3. Get Single Report
app.get('/api/reports/:id', async (req, res) => {
    try {
        const { id } = req.params;
        const pool = await sql.connect(dbConfig);

        // Get Report
        const reportResult = await pool.request()
            .input('Id', sql.NVarChar, id)
            .query('SELECT * FROM NCR_Reports WHERE NCRNumber = @Id');

        if (reportResult.recordset.length === 0) {
            return res.status(404).json({ error: 'Report not found' });
        }

        // Get Photos
        const photoResult = await pool.request()
            .input('Id', sql.NVarChar, id)
            .query('SELECT * FROM NCR_Photos WHERE NCRNumber = @Id');

        const report = reportResult.recordset[0];
        report.photos = photoResult.recordset; // Attach photos array

        res.json(report);
    } catch (err) {
        sendError(res, err, 'Failed to fetch report details');
    }
});

// 4. Create New Report
app.post('/api/reports', async (req, res) => {
    const transaction = new sql.Transaction();
    try {
        const { report, photos } = req.body; // photos array of base64 strings or file objects?
        // Assuming client handles file upload separately or sends base64 for now.
        // Wait, plan says "Handle photo uploads by sending dnd-upload files to the server to be saved to disk."

        // Ideally we use multer for files, but if we receive base64 JSON from current logic:
        // We'll write to disk.

        await transaction.begin();
        const request = new sql.Request(transaction);

        // Insert Report
        const insertResult = await request
            .input('TankSerial', sql.NVarChar, report.tankSerial || report.tank)
            .input('Department', sql.NVarChar, report.department || report.dept)
            .input('Auditee', sql.NVarChar, report.auditee || report.identifiedBy || '')
            .input('Auditor', sql.NVarChar, report.auditor || report.qualityRep || '')
            .input('LeadHand', sql.NVarChar, report.leadHand || '')
            .input('Manager', sql.NVarChar, report.manager || '')
            .input('Severity', sql.NVarChar, report.severity)
            .input('NonConformanceDescription', sql.NVarChar(sql.MAX), report.nonConformance || report.description)
            .input('CreatedBy', sql.NVarChar, report.employeeId || '1234')
            .query(`
                INSERT INTO NCR_Reports (TankSerial, Department, Auditee, Auditor, LeadHand, Manager, Severity, NonConformanceDescription, CreatedBy)
                OUTPUT INSERTED.NCRNumber
                VALUES (@TankSerial, @Department, @Auditee, @Auditor, @LeadHand, @Manager, @Severity, @NonConformanceDescription, @CreatedBy)
            `);

        const generatedNCRNumber = insertResult.recordset[0].NCRNumber;

        // Handle Photos
        if (photos && photos.length > 0) {
            for (let i = 0; i < photos.length; i++) {
                const photo = photos[i];
                // photo.data is base64 string
                const base64Data = photo.data.replace(/^data:image\/\w+;base64,/, "");
                const buffer = Buffer.from(base64Data, 'base64');
                const fileName = `${generatedNCRNumber}_${Date.now()}_${i}.jpg`;
                const filePath = path.join(PHOTOS_DIR, fileName);

                fs.writeFileSync(filePath, buffer);

                // Save path to DB
                await request
                    .input(`P_NCR_${i}`, sql.NVarChar, generatedNCRNumber)
                    .input(`P_File_${i}`, sql.NVarChar, fileName)
                    .input(`P_Path_${i}`, sql.NVarChar, filePath)
                    .query(`INSERT INTO NCR_Photos (NCRNumber, FileName, PhotoPath) VALUES (@P_NCR_${i}, @P_File_${i}, @P_Path_${i})`);
            }
        }

        await transaction.commit();
        res.json({ success: true, message: 'Report created successfully', ncrNo: generatedNCRNumber });

    } catch (err) {
        if (transaction._aborted === false) {
            await transaction.rollback();
        }
        sendError(res, err, 'Failed to create report');
    }
});

// 5. Update Report
// 5. Update Report
app.put('/api/reports/:id', async (req, res) => {
    const transaction = new sql.Transaction();
    try {
        const { id } = req.params;
        const { status, correctiveAction, rootCause, photos } = req.body;

        await transaction.begin();
        const request = new sql.Request(transaction);

        // Update Text Fields
        await request
            .input('Id', sql.NVarChar, id)
            .input('Status', sql.NVarChar, status)
            .input('CorrectiveAction', sql.NVarChar(sql.MAX), correctiveAction)
            .input('RootCause', sql.NVarChar(sql.MAX), rootCause)
            .query(`
                UPDATE NCR_Reports
                SET Status = @Status,
                    CorrectiveAction = @CorrectiveAction,
                    RootCause = @RootCause,
                    LastModifiedDate = GETDATE(),
                    ClosedDate = CASE
                        WHEN @Status IN ('Closed', 'Cancelled') AND ClosedDate IS NULL THEN GETDATE()
                        WHEN @Status NOT IN ('Closed', 'Cancelled') THEN NULL
                        ELSE ClosedDate
                    END
                WHERE NCRNumber = @Id
            `);

        // Handle New Photos
        if (photos && photos.length > 0) {
            for (let i = 0; i < photos.length; i++) {
                const photo = photos[i];
                // photo.data is base64 string
                const base64Data = photo.data.replace(/^data:image\/\w+;base64,/, "");
                const buffer = Buffer.from(base64Data, 'base64');
                const fileName = `${id}_${Date.now()}_${i}_edit.jpg`;
                const filePath = path.join(PHOTOS_DIR, fileName);

                fs.writeFileSync(filePath, buffer);

                // Save path to DB
                await request
                    .input(`P_NCR_E_${i}`, sql.NVarChar, id)
                    .input(`P_File_E_${i}`, sql.NVarChar, fileName)
                    .input(`P_Path_E_${i}`, sql.NVarChar, filePath)
                    .query(`INSERT INTO NCR_Photos (NCRNumber, FileName, PhotoPath) VALUES (@P_NCR_E_${i}, @P_File_E_${i}, @P_Path_E_${i})`);
            }
        }

        await transaction.commit();
        res.json({ success: true });
    } catch (err) {
        if (transaction._aborted === false) {
            await transaction.rollback();
        }
        sendError(res, err, 'Failed to update report');
    }
});

// 6. Dashboard Stats
app.get('/api/dashboard', async (req, res) => {
    try {
        const year = parseInt(req.query.year) || new Date().getFullYear();
        const month = req.query.month ? parseInt(req.query.month) : null;

        const pool = await sql.connect(dbConfig);

        const result = await pool.request()
            .input('Year', sql.Int, year)
            .input('Month', sql.Int, month)
            .execute('sp_GetDashboardStats');

        // Provide the multiple result sets
        res.json({
            statusCounts: result.recordsets[0],
            severityByMonth: result.recordsets[1],
            departmentStats: result.recordsets[2],
            departmentSeverity: result.recordsets[3]
        });
    } catch (err) {
        sendError(res, err, 'Failed to get dashboard stats');
    }
});

// 7. Get Available Years
app.get('/api/years', async (req, res) => {
    try {
        const pool = await sql.connect(dbConfig);
        const result = await pool.request()
            .query('SELECT DISTINCT YEAR(CreatedDate) as Year FROM NCR_Reports ORDER BY Year DESC');

        res.json(result.recordset.map(r => r.Year));
    } catch (err) {
        sendError(res, err, 'Failed to get years');
    }
});

// Start Server
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
